<div class="dropdown-container bg-white w-100  shadow position-absolute d-none" id="market_we_serve_dropdown" style="padding:60px;max-height:520px">
        <div class="row container-fluid m-0 p-0">
            <div class="col p-0 m-0">
                <div class="header-category d-flex" style="flex-flow:column wrap;max-height:353px;align-content:normal;align-items:flex-start">
                    <div style="width: calc(20% -20px);margin-bottom:25px">
                        <a href="#" class="text-decoration-underline text-dark">Shop All Markets We Serve</a>
                    </div>
                    <div style="width: calc(20% -20px);margin-bottom:25px">
                        <a href="#" class=" text-dark">Athletic / Sports</a>
                    </div>
                    <div style="width: calc(20% -20px);margin-bottom:25px">
                        <a href="#" class=" text-dark">Cosmetic Surgery / Dermatology</a>
                    </div>
                    <div style="width: calc(20% -20px);margin-bottom:25px">
                        <a href="#" class=" text-dark">Dental</a>
                    </div>
                    <div style="width: calc(20% -20px);margin-bottom:25px">
                        <a href="#" class=" text-dark">Dialysis</a>
                    </div>
                    <div style="width: calc(20% -20px);margin-bottom:25px">
                        <a href="#" class=" text-dark">Diagnostics / Laboratory</a>
                    </div>
                    <div style="width: calc(20% -20px);margin-bottom:25px">
                        <a href="#" class=" text-dark">DME (Durable Medical Equipment)</a>
                    </div>
                    <div style="width: calc(20% -20px);margin-bottom:25px">
                        <a href="#" class=" text-dark">Home / Personal Care</a>
                    </div>
                    <div style="width: calc(20% -20px);margin-bottom:25px">
                        <a href="#" class=" text-dark">Hospital / Emergency </a>
                    </div>
                    <div style="width: calc(20% -20px);margin-bottom:25px">
                        <a href="#" class=" text-dark">Nursing Home</a>
                    </div>
                    <div style="width: calc(20% -20px);margin-bottom:25px">
                        <a href="#" class=" text-dark">Patient Care</a>
                    </div>
                    <div style="width: calc(20% -20px);margin-bottom:25px">
                        <a href="#" class=" text-dark">Pharmacy & Retail</a>
                    </div>
                    <div style="width: calc(20% -20px);margin-bottom:25px">
                        <a href="#" class=" text-dark">Physical Rehabilitation / Chiropractic </a>
                    </div>
                    <div style="width: calc(20% -20px);margin-bottom:25px">
                        <a href="#" class=" text-dark">Physician Care / Clinic</a>
                    </div>
                    <div style="width: calc(20% -20px);margin-bottom:25px">
                        <a href="#" class=" text-dark">Respiratory</a>
                    </div>
                    <div style="width: calc(20% -20px);margin-bottom:25px">
                        <a href="#" class=" text-dark">Spa / Salon / Wellness</a>
                    </div>
                    <div style="width: calc(20% -20px);margin-bottom:25px">
                        <a href="#" class=" text-dark">Urology</a>
                    </div>
                    <div style="width: calc(20% -20px);margin-bottom:25px">
                        <a href="#" class=" text-dark">Urgent Care</a>
                    </div>
                    <div style="width: calc(20% -20px);margin-bottom:25px">
                        <a href="#" class=" text-dark">Veterinary</a>
                    </div>
                </div>
            </div>
            <div class="col-4 pe-0">

                <div class="p-0">

                    <div class=" w-max ms-auto p-0 position-relative" style="width:455px;height:371px">

                        <img class="w-100" src="<?= base_url("assets/images/image_dropdown-3.jpg") ?>" style="object-fit:cover" alt="image sample" />

                        <button class="btn bg-white position-absolute text-dark " style="width:max-content;bottom:20px;left:20px;font-weight:500">Shop Our Gloves Section</button>

                    </div>

                </div>

            </div>
        </div>
        

    </div>