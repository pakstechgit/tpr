<style>
    /* CSS for this page only */
    .active{
        font-weight: 600;
    }

    th,td{
        font-size: 13px !important;
    }

    label.required::after{
        content:" *";
        color: red;
    }

    .settings-category{
        font-size: 12px !important;
        color: #333333;
    }

    .list-group-item{
        border: none !important;
        padding: 0 px !important;
    }
</style>