<?php $this->load->view('client_page/latest_news/latest_news_styles') ?>
<?php $this->load->view('client_page/latest_news/latest_news_global_styles') ?>


<div class="latest-news">Latest News</div>
      <div class="na-news-menu-child">
        <div class="unsplashnfvdkihxylu-parent">
          <img
            class="unsplashnfvdkihxylu-icon"
            alt=""
            src="<?php echo base_url('assets_system/images/tpr_images/image-news.jpg'); ?>"
          />

          <div class="frame-wrapper1">
            <div class="lorem-ipsum-lorem-ipsum-dolor-wrapper">
              <div class="lorem-ipsum-lorem-container">
                <p class="your-one-stop-shop">Lorem ipsum</p>
                <p class="blank-line">&nbsp;</p>
                <p class="lorem-ipsum-dolor-sit-amet-co">
                  <span class="l">L</span>
                  <span
                    >orem ipsum dolor sit amet, consectetur adipiscing elit, sed
                    do eiusmod tempor incididunt ut labore et dolore magna
                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                    ullamco laboris nisi ut aliquip ex ea commodo consequat.
                  </span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
  