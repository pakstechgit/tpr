<?php defined('BASEPATH') OR exit('No direct script access allowed');
ob_start(); 
class Dashboard extends CI_Controller
{
    private $first_link = "<< ";
    private $last_link = " >>";
    private $next_link = " >";
    private $prev_link = "< ";
    private $pagination_config;
    function __construct(){
        parent::__construct();
        $this->load->model('modules/admin/admin_dashboard_model');
        $this->load->helper('form');
        $this->load->library('session');
        $this->load->library('Template');
        $this->load->library('pagination');
        $this->load->library('session');
        
        $this->pagination_config['attributes']       = ['class' => 'page-link'];
        $this->pagination_config['full_tag_open']    = '<nav><ul class="pagination">';
        $this->pagination_config['full_tag_close']   = '</ul></nav>';
        $this->pagination_config['cur_tag_open']     ='<li class="page-item active" aria-current="page"><a class="page-link" >';
        $this->pagination_config['prev_tag_open']    = '<li class="page-item">';
        $this->pagination_config['cur_tag_close']    = '</a></li>';
        $this->pagination_config['prev_tag_close']   = '</li>';
        $this->pagination_config['first_link']       = $this->first_link;
        $this->pagination_config['last_link']        = $this->last_link;
        $this->pagination_config['next_link']        = $this->next_link;
        $this->pagination_config['prev_link']        = $this->prev_link;
        $this->pagination_config['per_page']         = 10;
        $user_id                                     = $this->session->userdata('SESS_USER_ID');
        if(!$user_id){
            redirect('login/admin');
        }
        if($user_id){
            $user                                    = $this->admin_dashboard_model->GET_USER($user_id);
            if($user->user_type=='customer'){
                redirect('users/profile');
                return;
            }
        }
    }
    function index(){
        $data['TOTAL_CUSTOMERS']        = $this->admin_dashboard_model->GET_TOTAL_DATA('tbl_users');
        $data['TOTAL_PRODUCT_CAT']      = $this->admin_dashboard_model->GET_TOTAL_DATA('tbl_categories');
        $data['TOTAL_ORDERS']           = $this->admin_dashboard_model->GET_TOTAL_DATA('tbl_orders');
        $data['TOTAL_PRODUCT_BRAND']    = $this->admin_dashboard_model->GET_TOTAL_DATA('tbl_brands');
        $dat['TOP_PRODUCTS']            = $this->admin_dashboard_model->GET_TOP_PRODUCTS();
        $this->template->load('templates/admin_layout', 'modules/admin/dashboard_views',$data);
    }
}