<?php
class product_reviews_model extends CI_Model
{
    function GET_REVIEWS()
    {
        $sql = 'SELECT '
    }
}